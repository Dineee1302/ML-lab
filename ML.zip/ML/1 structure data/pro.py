import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

url = r"\Iris.csv" 
data = pd.read_csv(url)

print("Sample Data:\n", data.head())

X = data.drop('Species', axis=1)
y = data['Species']

encoder = LabelEncoder()
y_encoded = encoder.fit_transform(y)

X_train, X_test, y_train, y_test = train_test_split(
 X, y_encoded, test_size=0.2, random_state=42
)

print("\nStructured Training Data (X_train):\n", X_train.head())
print("\nTraining Labels (y_train):\n", y_train[:5])
print("\nData Structuring Completed Successfully!")
