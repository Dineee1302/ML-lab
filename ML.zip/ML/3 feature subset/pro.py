import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
import warnings

warnings.filterwarnings("ignore")

url = r"\Titanic-Dataset.csv"
data = pd.read_csv(url).copy()

data['Age'] = data['Age'].fillna(data['Age'].mean())
data['Embarked'] = data['Embarked'].fillna(data['Embarked'].mode()[0])
data = data.drop(columns=['Cabin', 'Name', 'Ticket'])

encoder = LabelEncoder()
data['Sex'] = encoder.fit_transform(data['Sex'])
data['Embarked'] = encoder.fit_transform(data['Embarked'])

X = data[['Pclass', 'Sex', 'Age', 'Fare', 'SibSp', 'Parch', 'Embarked']]
y = data['Survived']

correlation = X.corr(numeric_only=True)
print("Correlation Matrix:\n", correlation)
print("\nHighly Correlated Features (>|0.8|):")
print(correlation[(correlation > 0.8) | (correlation < -0.8)])

model = LogisticRegression(max_iter=2000, solver='lbfgs')
rfe = RFE(model, n_features_to_select=4)
fit = rfe.fit(X, y)

print("\nSelected Features using RFE:")
for i, col in enumerate(X.columns):
    if fit.support_[i]:
        print(f"- {col}")

rf = RandomForestClassifier(random_state=42)
rf.fit(X, y)
importances = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)

print("\nFeature Importance (Random Forest):\n", importances)

top_features = importances.head(4).index.tolist()
print("\nTop 4 Important Features (Final Selected):", top_features)