# Decision Tree Pruning on Noisy Monk2 Data
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

# -----------------------------
# STEP 1: Load the Monk2 Dataset
# -----------------------------
# Monk2 dataset has categorical attributes (symbolic form)
# You can download monk2.csv from: https://archive.ics.uci.edu/ml/machine-learning-databases/monks-problems/

# Example structure: class, a1, a2, a3, a4, a5, a6
# Here we’ll simulate loading it from a CSV file
data = pd.read_csv("E:/ML Program Dataset/monk2.csv")

data = data.drop('id', axis=1)
print("Dataset shape:", data.shape)
print(data.head())

# -----------------------------
# STEP 2: Encode Categorical Attributes
# -----------------------------
# Convert categorical attributes to numeric (Label Encoding)
from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()
for col in data.columns:
    data[col] = le.fit_transform(data[col])

# Split into features and target
X = data.drop('class', axis=1)
y = data['class']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# -----------------------------
# STEP 3: Train Unpruned Decision Tree
# -----------------------------
clf_unpruned = DecisionTreeClassifier(random_state=42)
clf_unpruned.fit(X_train, y_train)

# Evaluate
y_pred_unpruned = clf_unpruned.predict(X_test)
acc_unpruned = accuracy_score(y_test, y_pred_unpruned)
print("\nAccuracy (Unpruned Tree):", round(acc_unpruned, 3))

# -----------------------------
# STEP 4: Apply Cost Complexity Pruning
# -----------------------------
path = clf_unpruned.cost_complexity_pruning_path(X_train, y_train)
ccp_alphas = path.ccp_alphas  # array of effective alphas

# Train trees with different pruning strengths
clfs = []
for ccp_alpha in ccp_alphas:
    clf = DecisionTreeClassifier(random_state=42, ccp_alpha=ccp_alpha)
    clf.fit(X_train, y_train)
    clfs.append(clf)

# Evaluate accuracy for each alpha
train_scores = [clf.score(X_train, y_train) for clf in clfs]
test_scores = [clf.score(X_test, y_test) for clf in clfs]

# Plot accuracy vs alpha
plt.figure(figsize=(7, 5))
plt.plot(ccp_alphas, train_scores, marker='o', label='Train Accuracy', drawstyle="steps-post")
plt.plot(ccp_alphas, test_scores, marker='o', label='Test Accuracy', drawstyle="steps-post")
plt.xlabel("Effective Alpha (ccp_alpha)")
plt.ylabel("Accuracy")
plt.title("Cost Complexity Pruning - Accuracy vs Alpha")
plt.legend()
plt.show()

# -----------------------------
# STEP 5: Select Best Alpha and Prune Tree
# -----------------------------
best_alpha = ccp_alphas[np.argmax(test_scores)]
clf_pruned = DecisionTreeClassifier(random_state=42, ccp_alpha=best_alpha)
clf_pruned.fit(X_train, y_train)

# Evaluate pruned tree
y_pred_pruned = clf_pruned.predict(X_test)
acc_pruned = accuracy_score(y_test, y_pred_pruned)

print("\nBest ccp_alpha:", best_alpha)
print("Accuracy (Pruned Tree):", round(acc_pruned, 3))

# -----------------------------
# STEP 6: Compare Tree Structures
# -----------------------------
plt.figure(figsize=(10, 6))
plot_tree(clf_unpruned, filled=True, feature_names=X.columns)
plt.title("Unpruned Decision Tree")
plt.show()

plt.figure(figsize=(10, 6))
plot_tree(clf_pruned, filled=True, feature_names=X.columns)
plt.title("Pruned Decision Tree")
plt.show()

print("\nNumber of nodes in Unpruned Tree:", clf_unpruned.tree_.node_count)
print("Number of nodes in Pruned Tree:", clf_pruned.tree_.node_count)

print("\nAnalysis:")
print(f"Unpruned Tree Accuracy = {acc_unpruned:.3f}")
print(f"Pruned Tree Accuracy   = {acc_pruned:.3f}")
print("The pruned tree is smaller and often generalizes better on noisy Monk2 data.")
