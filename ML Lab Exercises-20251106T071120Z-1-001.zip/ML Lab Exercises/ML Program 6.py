# Bayesian Network for Heart Disease Diagnosis


import logging
logging.getLogger('pgmpy').setLevel(logging.ERROR)
import pandas as pd
from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.estimators import MaximumLikelihoodEstimator
from pgmpy.inference import VariableElimination

# Step 1: Load the Heart Disease dataset
data = pd.read_csv(r"E:\ML Program Dataset\heart.csv")

# Step 2: Rename columns for clarity
data.rename(columns={
    'cp': 'chest_pain_type',
    'trestbps': 'blood_pressure',
    'chol': 'cholesterol',
    'target': 'heart_disease'
}, inplace=True)

print("Dataset shape:", data.shape)
print("Columns:", data.columns.tolist())
print(data.head())

# Step 3: Discretize continuous variables into categories
# Bayesian Networks require discrete data
for col in ['age', 'blood_pressure', 'cholesterol', 'thalach']:
    data[col] = pd.cut(data[col], bins=3, labels=[0, 1, 2])

# Step 4: Convert all columns to categorical (discrete)
for col in data.columns:
    data[col] = data[col].astype('category')

# Step 5: Define the Bayesian Network structure (based on domain knowledge)
model = DiscreteBayesianNetwork([
    ('age', 'blood_pressure'),
    ('sex', 'cholesterol'),
    ('blood_pressure', 'heart_disease'),
    ('cholesterol', 'heart_disease'),
    ('thalach', 'heart_disease'),
    ('chest_pain_type', 'heart_disease'),
    ('restecg', 'heart_disease'),
    ('thal', 'heart_disease')
])

# Step 6: Fit the model using Maximum Likelihood Estimation
model.fit(data, estimator=MaximumLikelihoodEstimator)

# Step 7: Perform inference
infer = VariableElimination(model)

# Query 1: Probability of heart disease given age, sex, and chest pain type
query_result = infer.query(
    variables=['heart_disease'],
    evidence={'age': 1, 'sex': 1, 'chest_pain_type': 2}
)
print("\nProbability of Heart Disease given (age=mid, sex=male, chest_pain_type=2):")
print(query_result)

# Query 2: Probability of heart disease given normal BP and cholesterol
query_result2 = infer.query(
    variables=['heart_disease'],
    evidence={'blood_pressure': 1, 'cholesterol': 1}
)
print("\nProbability of Heart Disease given (normal BP & cholesterol):")
print(query_result2)
