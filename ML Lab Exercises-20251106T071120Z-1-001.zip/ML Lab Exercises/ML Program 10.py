import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# --------------------------
# Step 1: Load dataset
# Using Pima Diabetes dataset (binary classification)
url = "E:/ML Program Dataset/diabetes.csv"
data = pd.read_csv(url)

X = data.drop('Outcome', axis=1).values
y = data['Outcome'].values.reshape(-1, 1)  # Column vector

# Split into train and test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Feature scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# --------------------------
# Step 2: Define helper functions

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    return x * (1 - x)

# --------------------------
# Step 3: Initialize network parameters
input_dim = X_train.shape[1]
hidden_dim = 5
output_dim = 1
learning_rate = 0.1
epochs = 1000

# Initialize weights randomly
np.random.seed(42)
W1 = np.random.randn(input_dim, hidden_dim)
b1 = np.zeros((1, hidden_dim))
W2 = np.random.randn(hidden_dim, output_dim)
b2 = np.zeros((1, output_dim))

# --------------------------
# Step 4: Train network using backpropagation
for epoch in range(epochs):
    # Forward pass
    Z1 = np.dot(X_train, W1) + b1
    A1 = sigmoid(Z1)
    Z2 = np.dot(A1, W2) + b2
    A2 = sigmoid(Z2)  # Output layer

    # Compute loss (Mean Squared Error)
    loss = np.mean((y_train - A2) ** 2)

    # Backward pass
    dA2 = -(y_train - A2) * sigmoid_derivative(A2)
    dW2 = np.dot(A1.T, dA2)
    db2 = np.sum(dA2, axis=0, keepdims=True)

    dA1 = np.dot(dA2, W2.T) * sigmoid_derivative(A1)
    dW1 = np.dot(X_train.T, dA1)
    db1 = np.sum(dA1, axis=0, keepdims=True)

    # Update weights
    W2 -= learning_rate * dW2
    b2 -= learning_rate * db2
    W1 -= learning_rate * dW1
    b1 -= learning_rate * db1

    # Print loss every 100 epochs
    if (epoch + 1) % 100 == 0:
        print(f"Epoch {epoch+1}/{epochs}, Loss: {loss:.4f}")

# --------------------------
# Step 5: Test network
Z1_test = np.dot(X_test, W1) + b1
A1_test = sigmoid(Z1_test)
Z2_test = np.dot(A1_test, W2) + b2
A2_test = sigmoid(Z2_test)

y_pred = (A2_test > 0.5).astype(int)

# Accuracy
accuracy = np.mean(y_pred == y_test)
print("\nTest Accuracy:", accuracy)
